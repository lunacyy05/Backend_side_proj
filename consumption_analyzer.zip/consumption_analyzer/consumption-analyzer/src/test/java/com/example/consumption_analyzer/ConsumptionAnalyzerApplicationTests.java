package com.example.consumption_analyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumptionAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
