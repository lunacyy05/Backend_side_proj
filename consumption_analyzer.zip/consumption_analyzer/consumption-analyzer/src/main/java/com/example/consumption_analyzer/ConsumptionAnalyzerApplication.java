package com.example.consumption_analyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumptionAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumptionAnalyzerApplication.class, args);
	}

}
